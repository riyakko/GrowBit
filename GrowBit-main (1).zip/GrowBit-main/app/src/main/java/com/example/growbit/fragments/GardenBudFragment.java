package com.example.growbit.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.growbit.R;
import com.example.growbit.activities.MainActivity;
import com.google.android.material.tabs.TabLayout;

public class GardenBudFragment extends Fragment {

    // Bud is index 2
    private static final int CURRENT_TAB_INDEX = 2;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_bud, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TabLayout tabLayout = view.findViewById(R.id.tabs);

        // 1. SELECT THE BUD TAB VISUALLY
        tabLayout.post(() -> {
            TabLayout.Tab tab = tabLayout.getTabAt(CURRENT_TAB_INDEX);
            if (tab != null) {
                tab.select();
            }
        });

        // 2. HANDLE CLICKS
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() != CURRENT_TAB_INDEX) {
                    navigate(tab.getPosition());
                }
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });
    }

    private void navigate(int position) {
        // Check for MainActivity now, not GardenActivity
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).loadGardenFragment(position);
        }
    }
}