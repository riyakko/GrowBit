package com.example.growbit.utils;

import android.text.Editable;
import android.text.TextWatcher;

/**
 * A helper class that reduces code clutter.
 * It implements the unused methods of TextWatcher so you don't have to.
 */
public abstract class SimpleTextWatcher implements TextWatcher {
    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        // Not needed for simple error clearing
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
        // This is the one we usually care about
    }

    @Override
    public void afterTextChanged(Editable s) {
        // Not needed for simple error clearing
    }
}