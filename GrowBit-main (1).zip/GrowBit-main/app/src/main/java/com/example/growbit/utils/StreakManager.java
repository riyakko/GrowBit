package com.example.growbit.utils;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Calendar;

public class StreakManager {
    private static final String PREF_NAME = "GrowBitPrefs";
    private static final String KEY_STREAK = "active_streak";
    private static final String KEY_LAST_ACTIVITY = "last_activity_timestamp";

    /**
     * Records a streak-eligible activity (adding or completing a habit).
     */
    public static void recordActivity(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        int currentStreak = prefs.getInt(KEY_STREAK, 0);
        long lastActivityMillis = prefs.getLong(KEY_LAST_ACTIVITY, 0);

        long now = System.currentTimeMillis();
        Calendar today = Calendar.getInstance();
        today.setTimeInMillis(now);

        if (lastActivityMillis == 0) {
            // First ever activity
            saveStreak(context, 1, now);
            return;
        }

        Calendar lastActivity = Calendar.getInstance();
        lastActivity.setTimeInMillis(lastActivityMillis);

        // 1. Same day? Do nothing.
        if (isSameDay(lastActivity, today)) {
            return;
        }

        // 2. Next day? Increment.
        Calendar yesterday = (Calendar) today.clone();
        yesterday.add(Calendar.DAY_OF_YEAR, -1);

        if (isSameDay(lastActivity, yesterday)) {
            saveStreak(context, currentStreak + 1, now);
        } else {
            // 3. Gap of one or more days? Reset.
            saveStreak(context, 1, now);
        }
    }

    /**
     * Checks if the streak should be reset due to inactivity.
     * Should be called when the app starts or the Home screen is shown.
     */
    public static int getStreak(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        int currentStreak = prefs.getInt(KEY_STREAK, 0);
        long lastActivityMillis = prefs.getLong(KEY_LAST_ACTIVITY, 0);

        if (lastActivityMillis == 0) return 0;

        Calendar lastActivity = Calendar.getInstance();
        lastActivity.setTimeInMillis(lastActivityMillis);
        
        Calendar today = Calendar.getInstance();
        
        // If last activity was before yesterday, the streak is broken.
        Calendar yesterday = (Calendar) today.clone();
        yesterday.add(Calendar.DAY_OF_YEAR, -1);

        if (!isSameDay(lastActivity, today) && lastActivity.before(yesterday)) {
            // Reset to 0 if they missed at least one full calendar day (yesterday)
            saveStreak(context, 0, lastActivityMillis); // Keep timestamp to mark the 'last known'
            return 0;
        }

        return currentStreak;
    }

    private static boolean isSameDay(Calendar cal1, Calendar cal2) {
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
               cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR);
    }

    private static void saveStreak(Context context, int streak, long timestamp) {
        SharedPreferences.Editor editor = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE).edit();
        editor.putInt(KEY_STREAK, streak);
        editor.putLong(KEY_LAST_ACTIVITY, timestamp);
        editor.apply();
    }
}
