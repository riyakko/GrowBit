package com.example.growbit.utils;

import java.util.Calendar;

public final class DateUtils {

    private DateUtils() {} // Prevent instantiation

    /**
     * Calculates age based on year, month, and day.
     */
    public static int calculateAge(int year, int month, int day) {
        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        dob.set(year, month, day);

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
            age--;
        }

        return Math.max(age, 0);
    }
}