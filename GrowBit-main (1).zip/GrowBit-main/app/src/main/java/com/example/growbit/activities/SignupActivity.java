package com.example.growbit.activities;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.growbit.utils.DateUtils;
import com.example.growbit.R;
import com.example.growbit.utils.SimpleTextWatcher;
import com.example.growbit.utils.ViewUtils;

import java.util.Calendar;
import java.util.Locale;

public class SignupActivity extends AppCompatActivity {

    // UI Components
    private EditText etFullName;
    private EditText etEmail;
    private EditText etAge;
    private EditText etBirthday;
    private EditText etPassword;
    private EditText etConfirmPassword;
    private CheckBox cbTerms;
    private Button btnSignup;
    private ImageButton ibPasswordToggle;
    private ImageButton ibConfirmPasswordToggle;
    private TextView tvLoginLink;

    // State Variables
    private boolean isPasswordVisible = false;
    private boolean isConfirmPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        initializeViews();
        setupListeners();
        setupTextWatchers();
    }

    private void initializeViews() {
        etFullName = findViewById(R.id.et_full_name);
        etEmail = findViewById(R.id.et_email);
        etAge = findViewById(R.id.et_age);
        etBirthday = findViewById(R.id.et_birthday);
        etPassword = findViewById(R.id.et_password);
        etConfirmPassword = findViewById(R.id.et_confirm_password);
        cbTerms = findViewById(R.id.cb_terms_and_conditions);
        btnSignup = findViewById(R.id.btn_signup);
        ibPasswordToggle = findViewById(R.id.ib_password);
        ibConfirmPasswordToggle = findViewById(R.id.ib_confirm_password);
        tvLoginLink = findViewById(R.id.tv_login);
    }

    private void setupListeners() {
        // Password Visibility Toggles
        ibPasswordToggle.setOnClickListener(v -> {
            isPasswordVisible = !isPasswordVisible;
            ViewUtils.togglePasswordVisibility(etPassword, ibPasswordToggle, isPasswordVisible);
        });

        ibConfirmPasswordToggle.setOnClickListener(v -> {
            isConfirmPasswordVisible = !isConfirmPasswordVisible;
            ViewUtils.togglePasswordVisibility(etConfirmPassword, ibConfirmPasswordToggle, isConfirmPasswordVisible);
        });

        // Date Picker
        etBirthday.setOnClickListener(v -> showDatePicker());

        // Navigation
        tvLoginLink.setOnClickListener(v -> navigateToLogin());

        // Signup Action
        btnSignup.setOnClickListener(v -> attemptSignup());

        etConfirmPassword.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                attemptSignup(); // Trigger the signup logic
                return true;
            }
            return false;
        });
    }


    private void setupTextWatchers() {
        // Helper to clear errors for all text fields

        etFullName.addTextChangedListener(new SimpleTextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                etFullName.setError(null);
            }
        });

        etEmail.addTextChangedListener(new SimpleTextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                etEmail.setError(null);
            }
        });

        etPassword.addTextChangedListener(new SimpleTextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                etPassword.setError(null);
            }
        });

        etConfirmPassword.addTextChangedListener(new SimpleTextWatcher() {
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                etConfirmPassword.setError(null);
            }
        });
    }


    /**
     * Shows a native DatePickerDialog.
     * Note: Removed Holo theme to ensure consistency with modern Material Design.
     */
    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int currentYear = calendar.get(Calendar.YEAR);
        int currentMonth = calendar.get(Calendar.MONTH);
        int currentDay = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String formattedDate = String.format(Locale.US, "%02d/%02d/%d", selectedMonth + 1, selectedDay, selectedYear);
                    etBirthday.setText(formattedDate);
                    etAge.setText(String.valueOf(DateUtils.calculateAge(selectedYear, selectedMonth, selectedDay)));
                    etBirthday.setError(null); // Clear error if one existed
                },
                currentYear, currentMonth, currentDay
        );

        // Restrict to past dates only
        datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        datePickerDialog.show();
    }

    private void attemptSignup() {
        if (validateInputs()) {
            performSignupSuccess();
        }
    }

    /**
     * Validates all input fields.
     * Uses .setError() to provide specific feedback on the UI fields.
     * @return true if all inputs are valid, false otherwise.
     */
    private boolean validateInputs() {
        boolean isValid = true;

        String name = etFullName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String confirmPass = etConfirmPassword.getText().toString().trim();
        String birthday = etBirthday.getText().toString().trim();

        // Name Validation
        if (name.isEmpty()) {
            etFullName.setError("Full name is required");
            etFullName.requestFocus();
            isValid = false;
        }

        // Email Validation
        if (email.isEmpty()) {
            etEmail.setError("Email is required");
            if (isValid) etEmail.requestFocus();
            isValid = false;
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Please enter a valid email address");
            if (isValid) etEmail.requestFocus();
            isValid = false;
        }

        // Birthday Validation
        if (birthday.isEmpty()) {
            etBirthday.setError("Birthday is required");
            // Do not request focus for date picker fields usually, just show error
            isValid = false;
        }

        // Password Validation
        if (password.isEmpty()) {
            etPassword.setError("Password is required");
            if (isValid) etPassword.requestFocus();
            isValid = false;
        } else if (password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            if (isValid) etPassword.requestFocus();
            isValid = false;
        }

        // Confirm Password Validation
        if (!password.equals(confirmPass)) {
            etConfirmPassword.setError("Passwords do not match");
            if (isValid) etConfirmPassword.requestFocus();
            isValid = false;
        }

        // Terms Validation
        if (!cbTerms.isChecked()) {
            Toast.makeText(this, "You must accept the Terms and Conditions", Toast.LENGTH_SHORT).show();
            isValid = false;
        }

        return isValid;
    }

    private void performSignupSuccess() {
        Toast.makeText(this, "Account Created Successfully!", Toast.LENGTH_LONG).show();
        navigateToLogin();
    }

    private void navigateToLogin() {
        Intent intent = new Intent(SignupActivity.this, LoginActivity.class);
        // clearTask ensures the user cannot go back to Signup by pressing back button
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}