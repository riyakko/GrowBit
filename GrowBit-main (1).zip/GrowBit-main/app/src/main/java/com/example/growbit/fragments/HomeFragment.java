package com.example.growbit.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.growbit.R;
import com.example.growbit.activities.MainActivity;

public class HomeFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupGardenNavigation(view);
    }

    private void setupGardenNavigation(View view) {
        ImageButton btnSeed = view.findViewById(R.id.ib_seed);
        ImageButton btnSprout = view.findViewById(R.id.ib_sprout);
        ImageButton btnBud = view.findViewById(R.id.ib_bud);
        ImageButton btnTree = view.findViewById(R.id.ib_tree);
        ImageButton btnMainGarden = view.findViewById(R.id.ib_garden);

        // Instead of Intents, we ask MainActivity to swap fragments
        btnSeed.setOnClickListener(v -> navigateTo(0));
        btnSprout.setOnClickListener(v -> navigateTo(1));
        btnBud.setOnClickListener(v -> navigateTo(2));
        btnTree.setOnClickListener(v -> navigateTo(3));

        // Default garden button goes to the last visited stage, or Tree (3)
        btnMainGarden.setOnClickListener(v -> navigateTo(3));
    }

    private void navigateTo(int index) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).loadGardenFragment(index);
        }
    }
}