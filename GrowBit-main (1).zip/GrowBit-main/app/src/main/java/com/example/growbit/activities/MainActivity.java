package com.example.growbit.activities;

import android.os.Bundle;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.growbit.R;
import com.example.growbit.fragments.GardenBudFragment;
import com.example.growbit.fragments.GardenSeedFragment;
import com.example.growbit.fragments.GardenSproutFragment;
import com.example.growbit.fragments.GardenTreeFragment;
import com.example.growbit.fragments.HomeFragment;
import com.example.growbit.fragments.UserProfileFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    // Constants for Garden Stages
    public static final int STAGE_SEED = 0;
    public static final int STAGE_SPROUT = 1;
    public static final int STAGE_BUD = 2;
    public static final int STAGE_TREE = 3;

    private BottomNavigationView bottomNav;

    // UX: Remember the last garden stage viewed (Defaults to SEED)
    private int currentGardenStage = STAGE_SEED;

    // UX: Variable for "Double Back to Exit"
    private long backPressedTime;
    private Toast backToast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupWindowInsets();
        setupBottomNavigation();
        setupBackNavigation();

        if (savedInstanceState == null) {
            loadFragment(new HomeFragment());
        }
    }

    private void initializeViews() {
        bottomNav = findViewById(R.id.bottom_navigation);
    }

    private void setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, 0);
            return insets;
        });
    }

    private void setupBottomNavigation() {
        bottomNav.setOnItemSelectedListener(item -> {
            // Prevent reloading the current tab
            if (bottomNav.getSelectedItemId() == item.getItemId()) {
                return false;
            }

            int itemId = item.getItemId();

            if (itemId == R.id.nav_home) {
                loadFragment(new HomeFragment());
                return true;
            } else if (itemId == R.id.nav_garden_home) {
                // IMPROVEMENT 1: Load the LAST viewed stage, not always the Seed
                loadGardenFragment(currentGardenStage);
                return true;
            } else if (itemId == R.id.nav_profile) {
                loadFragment(new UserProfileFragment());
                return true;
            }

            return false;
        });
    }

    private void setupBackNavigation() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (bottomNav.getSelectedItemId() != R.id.nav_home) {
                    // If not on Home, go to Home
                    bottomNav.setSelectedItemId(R.id.nav_home);
                } else {
                    // IMPROVEMENT 2: Double-back to exit
                    if (backPressedTime + 2000 > System.currentTimeMillis()) {
                        if (backToast != null) backToast.cancel();
                        finish(); // Actually close the app
                    } else {
                        if (backToast != null) backToast.cancel();
                        backToast = Toast.makeText(MainActivity.this, "Press back again to exit", Toast.LENGTH_SHORT);
                        backToast.show();
                    }
                    backPressedTime = System.currentTimeMillis();
                }
            }
        });
    }

    private void loadFragment(Fragment fragment) {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Optional: Add simple fade animation for polish
        transaction.setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out);

        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
    }

    /**
     * Loads a specific stage of the garden and remembers it.
     */
    public void loadGardenFragment(int stageIndex) {
        // Update our memory of where the user is
        this.currentGardenStage = stageIndex;

        Fragment selectedFragment;
        switch (stageIndex) {
            case STAGE_SEED:   selectedFragment = new GardenSeedFragment(); break;
            case STAGE_SPROUT: selectedFragment = new GardenSproutFragment(); break;
            case STAGE_BUD:    selectedFragment = new GardenBudFragment(); break;
            case STAGE_TREE:   selectedFragment = new GardenTreeFragment(); break;
            default:           selectedFragment = new GardenSeedFragment(); break;
        }

        // Visually update the bottom nav
        // Note: checking strictly to prevent infinite loops if called from the listener
        if (bottomNav.getSelectedItemId() != R.id.nav_garden_home) {
            bottomNav.getMenu().findItem(R.id.nav_garden_home).setChecked(true);
        }

        loadFragment(selectedFragment);
    }
}