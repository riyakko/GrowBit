package com.example.growbit.utils;

import android.graphics.Typeface;
import android.text.InputType;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.growbit.R;

/**
 * A utility class for common UI operations.
 * declared 'final' because it should not be subclassed.
 */
public final class ViewUtils {

    // Private constructor prevents instantiation (e.g., "new ViewUtils()")
    private ViewUtils() {}

    /**
     * Toggles password visibility on an EditText and updates the toggle icon.
     * * @param editText     The input field for the password.
     * @param toggleButton The button used to toggle visibility.
     * @param isVisible    The current desired visibility state (true = visible).
     */
    public static void togglePasswordVisibility(EditText editText, ImageButton toggleButton, boolean isVisible) {
        // 1. Save the current custom font (e.g., Poppins) so it doesn't get reset
        Typeface currentTypeface = editText.getTypeface();

        // 2. Save the cursor position so it doesn't jump to the start
        int cursorPosition = editText.getSelectionEnd();

        // 3. Toggle the input type and icon
        if (isVisible) {
            editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
            toggleButton.setImageResource(R.drawable.ic_visibility_off);
        } else {
            editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
            toggleButton.setImageResource(R.drawable.ic_visibility);
        }

        // 4. Restore the custom font
        editText.setTypeface(currentTypeface);

        // 5. Restore cursor position safely
        if (cursorPosition >= 0) {
            editText.setSelection(cursorPosition);
        }
    }
}