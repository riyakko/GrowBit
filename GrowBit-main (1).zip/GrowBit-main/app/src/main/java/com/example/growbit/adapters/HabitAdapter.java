package com.example.growbit.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.growbit.Habit;
import com.example.growbit.R;
import java.util.List;

public class HabitAdapter extends RecyclerView.Adapter<HabitAdapter.HabitViewHolder> {

    private List<Habit> habits;
    private OnHabitClickListener listener;

    public interface OnHabitClickListener {
        void onHabitClick(Habit habit);
        void onDeleteClick(Habit habit);
    }

    public HabitAdapter(List<Habit> habits, OnHabitClickListener listener) {
        this.habits = habits;
        this.listener = listener;
    }

    @NonNull
    @Override
    public HabitViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.habit_item, parent, false);
        return new HabitViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HabitViewHolder holder, int position) {
        Habit habit = habits.get(position);
        holder.bind(habit, listener);
    }

    @Override
    public int getItemCount() {
        return habits.size();
    }

    public void updateHabits(List<Habit> newHabits) {
        this.habits = newHabits;
        notifyDataSetChanged();
    }

    static class HabitViewHolder extends RecyclerView.ViewHolder {
        TextView nameText;
        ProgressBar progressBar;
        TextView progressText;
        View checkbox;
        View deleteButton;

        public HabitViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.habit_name);
            progressBar = itemView.findViewById(R.id.progress_bar);
            progressText = itemView.findViewById(R.id.progress_text);
            checkbox = itemView.findViewById(R.id.habit_checkbox);
            deleteButton = itemView.findViewById(R.id.delete_button);
        }

        public void bind(Habit habit, OnHabitClickListener listener) {
            nameText.setText(habit.getName());
            int progress = habit.getProgressPercentage();
            progressBar.setProgress(progress);
            progressText.setText(progress + "%");

            checkbox.setOnClickListener(v -> listener.onHabitClick(habit));
            deleteButton.setOnClickListener(v -> listener.onDeleteClick(habit));
        }
    }
}
