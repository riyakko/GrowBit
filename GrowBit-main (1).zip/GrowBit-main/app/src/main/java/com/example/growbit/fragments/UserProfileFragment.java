package com.example.growbit.fragments;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.growbit.R;
import com.example.growbit.activities.LoginActivity;

public class UserProfileFragment extends Fragment {

    // UI Components
    private ImageView profileImage;
    private TextView tvName, tvEmail;
    private TextView tvTotalHabits, tvCurrentStreak, tvLongestStreak, tvFullyGrown;
    private Button btnEditProfile;
    private Button btnChangeName, btnChangeEmail, btnChangePassword;
    private Button btnTerms, btnAppVersion;
    private Button btnLogout;

    public UserProfileFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_user_profile, container, false);

        initializeViews(view);
        setupListeners();
        loadUserData();

        return view;
    }

    private void initializeViews(View view) {
        profileImage = view.findViewById(R.id.img_user_profile);
        tvName = view.findViewById(R.id.tv_user_name);
        tvEmail = view.findViewById(R.id.tv_user_email);
        btnEditProfile = view.findViewById(R.id.btn_edit_profile);

        tvTotalHabits = view.findViewById(R.id.tv_val_total_habits);
        tvCurrentStreak = view.findViewById(R.id.tv_val_streak);
        tvLongestStreak = view.findViewById(R.id.tv_val_long_streak);
        tvFullyGrown = view.findViewById(R.id.tv_val_grown);

        btnChangeName = view.findViewById(R.id.btn_change_name);
        btnChangeEmail = view.findViewById(R.id.btn_change_email);
        btnChangePassword = view.findViewById(R.id.btn_change_password);

        btnTerms = view.findViewById(R.id.btn_terms_and_privacy);
        btnAppVersion = view.findViewById(R.id.btn_app_version);

        btnLogout = view.findViewById(R.id.btn_logout);
    }

    private void setupListeners() {
        btnEditProfile.setOnClickListener(v -> showEditProfileDialog());
        btnChangeName.setOnClickListener(v -> showChangeNameDialog());
        btnChangeEmail.setOnClickListener(v -> showChangeEmailDialog());
        btnChangePassword.setOnClickListener(v -> showChangePasswordDialog());
        btnTerms.setOnClickListener(v -> showTermsDialog());

        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    private void showEditProfileDialog() {
        // Implement image selection logic here
        Toast.makeText(getContext(), "Edit Profile Logic to be implemented", Toast.LENGTH_SHORT).show();
    }

    private void showChangeNameDialog() {
        Dialog dialog = new Dialog(getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_edit_username);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        TextView tvCurrentName = dialog.findViewById(R.id.tv_current_username);
        EditText etNewName = dialog.findViewById(R.id.et_new_username);
        EditText etPassword = dialog.findViewById(R.id.et_password_verify);
        Button btnConfirm = dialog.findViewById(R.id.btn_confirm);
        Button btnCancel = dialog.findViewById(R.id.btn_cancel);

        tvCurrentName.setText(tvName.getText());

        btnConfirm.setOnClickListener(v -> {
            String newName = etNewName.getText().toString().trim();
            if (newName.isEmpty()) {
                etNewName.setError("Username cannot be empty");
                return;
            }
            // Mock validation - you should verify password here
            tvName.setText(newName);
            dialog.dismiss();
            Toast.makeText(getContext(), "Username updated!", Toast.LENGTH_SHORT).show();
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showChangeEmailDialog() {
        Dialog dialog = new Dialog(getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_edit_email);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        TextView tvCurrentEmail = dialog.findViewById(R.id.tv_current_email);
        EditText etNewEmail = dialog.findViewById(R.id.et_new_email);
        EditText etPassword = dialog.findViewById(R.id.et_password_verify);
        Button btnConfirm = dialog.findViewById(R.id.btn_confirm);
        Button btnCancel = dialog.findViewById(R.id.btn_cancel);

        tvCurrentEmail.setText(tvEmail.getText());

        btnConfirm.setOnClickListener(v -> {
            String newEmail = etNewEmail.getText().toString().trim();
            if (newEmail.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(newEmail).matches()) {
                etNewEmail.setError("Enter a valid email");
                return;
            }
            tvEmail.setText(newEmail);
            dialog.dismiss();
            Toast.makeText(getContext(), "Email updated!", Toast.LENGTH_SHORT).show();
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showChangePasswordDialog() {
        Dialog dialog = new Dialog(getContext());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_change_password);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        EditText etOldPassword = dialog.findViewById(R.id.et_old_password);
        EditText etNewPassword = dialog.findViewById(R.id.et_new_password);
        EditText etConfirmPassword = dialog.findViewById(R.id.et_confirm_new_password);
        Button btnConfirm = dialog.findViewById(R.id.btn_confirm);
        Button btnCancel = dialog.findViewById(R.id.btn_cancel);

        btnConfirm.setOnClickListener(v -> {
            String newPass = etNewPassword.getText().toString();
            String confirmPass = etConfirmPassword.getText().toString();
            if (newPass.length() < 6) {
                etNewPassword.setError("Password too short");
                return;
            }
            if (!newPass.equals(confirmPass)) {
                etConfirmPassword.setError("Passwords don't match");
                return;
            }
            dialog.dismiss();
            Toast.makeText(getContext(), "Password changed successfully!", Toast.LENGTH_SHORT).show();
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

    private void showTermsDialog() {
        // Implement Terms & Privacy Policy display logic here
        Toast.makeText(getContext(), "Terms and Privacy Policy to be implemented", Toast.LENGTH_SHORT).show();
    }

    private void loadUserData() {
        tvName.setText("Alex Martinez");
        tvEmail.setText("alexmartinez@gmail.com");
        tvTotalHabits.setText("8 days");
        tvCurrentStreak.setText("5 days");
        tvLongestStreak.setText("12 days");
        tvFullyGrown.setText("3");
    }
}
