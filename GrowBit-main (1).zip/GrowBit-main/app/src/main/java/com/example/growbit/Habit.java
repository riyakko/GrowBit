package com.example.growbit;

import java.util.Calendar;

public class Habit {
    public enum Stage {
        SEED, SPROUT, BUD, TREE
    }

    private String name;
    private int daysClicked;
    private Stage stage;
    private long lastClickedTimestamp;

    public Habit(String name) {
        this.name = name;
        this.daysClicked = 0;
        this.stage = Stage.SEED;
        this.lastClickedTimestamp = 0;
    }

    public String getName() {
        return name;
    }

    public int getDaysClicked() {
        return daysClicked;
    }

    public Stage getStage() {
        return stage;
    }

    public boolean canClickToday() {
        if (lastClickedTimestamp == 0) return true;

        Calendar lastClick = Calendar.getInstance();
        lastClick.setTimeInMillis(lastClickedTimestamp);

        Calendar now = Calendar.getInstance();

        return now.get(Calendar.YEAR) != lastClick.get(Calendar.YEAR) ||
               now.get(Calendar.DAY_OF_YEAR) != lastClick.get(Calendar.DAY_OF_YEAR);
    }

    public boolean addClick() {
        if (canClickToday()) {
            daysClicked++;
            lastClickedTimestamp = System.currentTimeMillis();
            updateStage();
            return true;
        }
        return false;
    }

    private void updateStage() {
        if (daysClicked >= 60) {
            stage = Stage.TREE;
        } else if (daysClicked >= 30) {
            stage = Stage.BUD;
        } else if (daysClicked >= 10) {
            stage = Stage.SPROUT;
        } else {
            stage = Stage.SEED;
        }
    }

    public int getProgressPercentage() {
        if (stage == Stage.SEED) return (int) ((daysClicked / 10.0) * 100);
        if (stage == Stage.SPROUT) return (int) (((daysClicked - 10) / 20.0) * 100);
        if (stage == Stage.BUD) return (int) (((daysClicked - 30) / 30.0) * 100);
        return 100;
    }
}
