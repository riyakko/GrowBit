package com.example.growbit.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.growbit.R;
import com.example.growbit.utils.SimpleTextWatcher;
import com.example.growbit.utils.ViewUtils;

public class LoginActivity extends AppCompatActivity {

    // UI Components
    private EditText etEmail;
    private EditText etPassword;
    private Button btnLogin;
    private TextView tvSignupLink;
    private ImageButton ibPasswordToggle;

    // State Variables
    private boolean isPasswordVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        initializeViews();
        setupListeners();
        setupTextWatchers();
    }

    private void initializeViews() {
        etEmail = findViewById(R.id.et_email_address);
        etPassword = findViewById(R.id.et_password);
        btnLogin = findViewById(R.id.btn_login);
        tvSignupLink = findViewById(R.id.tv_signup);
        ibPasswordToggle = findViewById(R.id.ib_login_password_toggle);
    }

    private void setupListeners() {
        // Toggle Password Visibility
        ibPasswordToggle.setOnClickListener(v -> {
            isPasswordVisible = !isPasswordVisible;
            ViewUtils.togglePasswordVisibility(etPassword, ibPasswordToggle, isPasswordVisible);
        });

        // Navigation
        tvSignupLink.setOnClickListener(v -> navigateToSignup());

        // Login Action
        btnLogin.setOnClickListener(v -> attemptLogin());

        etPassword.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                attemptLogin(); // Trigger login when "Done" is pressed
                return true;
            }
            return false;
        });
    }


    private void setupTextWatchers() {
        // Clear error when user types in Email
        etEmail.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                etEmail.setError(null);
            }
        });

        // Clear error when user types in Password
        etPassword.addTextChangedListener(new SimpleTextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                etPassword.setError(null);
            }
        });
    }


    private void attemptLogin() {
        btnLogin.setEnabled(false);
        btnLogin.setText("Logging in...");

        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        // 1. Validate Inputs (Handle UI errors)
        if (!validateInputs(email, password)) {
            btnLogin.setEnabled(true);
            btnLogin.setText("Login");
            return;
        }

        // 2. Authenticate (Mock Logic)
        if (authenticateMockUser(email, password)) {
            performLoginSuccess();
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            btnLogin.setEnabled(true);
            btnLogin.setText("Login");
        }
    }

    private boolean validateInputs(String email, String password) {
        boolean isValid = true;
        boolean isTestUser = email.equals("test");

        // --- Email Validation ---
        if (email.isEmpty()) {
            etEmail.setError("Email is required");
            etEmail.requestFocus();
            isValid = false;
        } else if (!isTestUser && !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Please enter a valid email address");
            etEmail.requestFocus();
            isValid = false;
        }

        // --- Password Validation ---
        if (password.isEmpty()) {
            etPassword.setError("Password is required");
            if (isValid) etPassword.requestFocus();
            isValid = false;
        } else if (!isTestUser && password.length() < 6) {
            etPassword.setError("Password must be at least 6 characters");
            if (isValid) etPassword.requestFocus();
            isValid = false;
        }

        return isValid;
    }

    private boolean authenticateMockUser(String email, String password) {
        return email.equals("test") && password.equals("test");
    }

    private void performLoginSuccess() {
        Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show();
        
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void navigateToSignup() {
        Intent intent = new Intent(LoginActivity.this, SignupActivity.class);
        startActivity(intent);
    }
}
