package com.example.growbit.fragments;

import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.growbit.Habit;
import com.example.growbit.HabitManager;
import com.example.growbit.R;
import com.example.growbit.activities.MainActivity;
import com.example.growbit.adapters.HabitAdapter;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;

public class GardenSeedFragment extends Fragment implements HabitAdapter.OnHabitClickListener, HabitManager.OnHabitChangedListener {

    private static final int CURRENT_TAB_INDEX = 0;
    private HabitAdapter adapter;
    private HabitManager habitManager;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_seed, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        habitManager = HabitManager.getInstance();
        habitManager.setListener(this);

        TabLayout tabLayout = view.findViewById(R.id.tabs);
        tabLayout.post(() -> {
            TabLayout.Tab tab = tabLayout.getTabAt(CURRENT_TAB_INDEX);
            if (tab != null) tab.select();
        });

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getPosition() != CURRENT_TAB_INDEX) navigate(tab.getPosition());
            }
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {}
        });

        RecyclerView recyclerView = view.findViewById(R.id.habitRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new HabitAdapter(habitManager.getHabitsByStage(Habit.Stage.SEED), this);
        recyclerView.setAdapter(adapter);

        TextInputEditText addHabitEditText = view.findViewById(R.id.addHabitEditText);
        addHabitEditText.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                String habitName = addHabitEditText.getText().toString().trim();
                if (!habitName.isEmpty()) {
                    habitManager.addHabit(new Habit(habitName));
                    addHabitEditText.setText("");
                }
                return true;
            }
            return false;
        });
    }

    @Override
    public void onHabitClick(Habit habit) {
        habitManager.recordClick(habit);
    }

    @Override
    public void onDeleteClick(Habit habit) {
        habitManager.deleteHabit(habit);
    }

    @Override
    public void onHabitsUpdated() {
        if (adapter != null) {
            adapter.updateHabits(habitManager.getHabitsByStage(Habit.Stage.SEED));
        }
    }

    private void navigate(int position) {
        if (getActivity() instanceof MainActivity) {
            ((MainActivity) getActivity()).loadGardenFragment(position);
        }
    }
}
