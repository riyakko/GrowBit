package com.example.growbit;

import android.content.Context;
import com.example.growbit.utils.StreakManager;
import java.util.ArrayList;
import java.util.List;

public class HabitManager {
    private static HabitManager instance;
    private List<Habit> habits;
    private OnHabitChangedListener listener;
    private Context context;

    public interface OnHabitChangedListener {
        void onHabitsUpdated();
    }

    private HabitManager() {
        habits = new ArrayList<>();
    }

    public static synchronized HabitManager getInstance() {
        if (instance == null) {
            instance = new HabitManager();
        }
        return instance;
    }

    public void init(Context context) {
        this.context = context.getApplicationContext();
    }

    public void setListener(OnHabitChangedListener listener) {
        this.listener = listener;
    }

    public void addHabit(Habit habit) {
        habits.add(habit);
        if (context != null) {
            StreakManager.recordActivity(context);
        }
        notifyListener();
    }

    public List<Habit> getHabitsByStage(Habit.Stage stage) {
        List<Habit> stageHabits = new ArrayList<>();
        for (Habit h : habits) {
            if (h.getStage() == stage) {
                stageHabits.add(h);
            }
        }
        return stageHabits;
    }

    public void recordClick(Habit habit) {
        if (habit.addClick()) {
            if (context != null) {
                StreakManager.recordActivity(context);
            }
            notifyListener();
        }
    }

    public void deleteHabit(Habit habit) {
        habits.remove(habit);
        notifyListener();
    }

    private void notifyListener() {
        if (listener != null) {
            listener.onHabitsUpdated();
        }
    }
}
